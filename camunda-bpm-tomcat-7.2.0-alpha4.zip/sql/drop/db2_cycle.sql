
    drop table cy_bpmn_diagram
;

    drop table cy_connector_attributes
;

    drop table cy_connector_config
;

    drop table cy_connector_cred
;

    drop table cy_roundtrip
;

    drop table cy_user
;

    drop table cy_id_table
;
