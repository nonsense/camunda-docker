
    drop table cy_bpmn_diagram cascade constraints
;

    drop table cy_connector_attributes cascade constraints
;

    drop table cy_connector_config cascade constraints
;

    drop table cy_connector_cred cascade constraints
;

    drop table cy_roundtrip cascade constraints
;

    drop table cy_user cascade constraints
;

    drop table cy_id_table cascade constraints
;
