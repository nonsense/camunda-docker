'use strict';

/* Filters */

angular
  .module('cycle.filters', []);